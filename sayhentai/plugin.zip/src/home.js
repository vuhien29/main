load('config.js');
function execute() {
    return Response.success([
        { title: "Cập Nhật", input: BASE_URL + "/", script: "gen.js" },
        { title: "Manhwa", input: BASE_URL + "/genre/manhwa", script: "gen.js" },
        { title: "Manga", input: BASE_URL + "/genre/manga", script: "gen.js" },
        { title: "Manhua", input: BASE_URL + "/genre/manhua", script: "gen.js" },
        { title: "Thể loại", input: BASE_URL + "/genre/genre", script: "gen.js" },
    ]);
}
